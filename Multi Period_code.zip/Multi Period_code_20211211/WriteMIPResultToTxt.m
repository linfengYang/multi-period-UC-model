function WriteMIPResultToTxt(fid,index,N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs)
%WRITERESULTTOTXT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if(index == 1 )
    fprintf(fid,'Unit_Number\t Objval\t Status\t Runime\t MipGap\t nodes\t iterations\t cuts\t cons\t vars\t nonzs\t pre_cons\t pre_vars\t pre_nonzs\r\n');
    fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs);
else
    fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs);
end
end
