function tao = tao_state( m,t,M,tao_location,var,Time_off_min )
%�ѱ���uת����tao
    A = tao_location{m};
    lo = reshape(A(m : t + 1,max(m - 1,t - Time_off_min) + 1 : m + M - 1),(t + 2 - m) * (m + M - 1 - max(m - 1,t - Time_off_min)),1);
    tao = lo(lo ~= 0);
    tao = tao + var * ones(size(tao,1),1);
end

