function result = CplexSolve(problem,model,GAP,TimeLimit,boolean_MILP)
%��cplex���
    
if(strcmp(problem,'MIP'))    %������MIP����
    
    cplex_class = Cplex('MIP');
    cplex_class.Model.sense = 'minimize';    
    cplex_class.Model.Q = model.H;    
    cplex_class.Model.obj = model.f;
    cplex_class.Model.lb = model.lb;
    cplex_class.Model.ub = model.ub;
    cplex_class.Model.A = [model.Aineq;model.Aeq];
    cplex_class.Model.lhs = [-Inf .* ones(size(model.bineq,1),1);model.beq];
    cplex_class.Model.rhs = [model.bineq;model.beq];
    cplex_class.Model.ctype = model.ctype;
    
%     cplex_class.DisplayFunc = 'off';      %off����ʾ������
    cplex_class.Param.mip.tolerances.mipgap.Cur = GAP;
    cplex_class.Param.timelimit.Cur = TimeLimit;
    cplex_class.Param.barrier.convergetol.Cur = 1e-12;      %Լ���������  
%     cplex_class.writeModel('2P.mps');     %�����ѧģ��

    cplex_class.solve();
    
    result.x = cplex_class.Solution.x;
    result.objval = cplex_class.Solution.objval;
    
    if(boolean_MILP == 1)    %1��ʾĿ�꺯�����Ի�
        result.objval = 0.5 * result.x' * model.orig_H * result.x + model.orig_f' * result.x;
    end
    
    result.status = cplex_class.Solution.statusstring;
    result.runtime = cplex_class.Solution.time;
    result.mipgap = cplex_class.Solution.miprelgap;
    result.nodecount = cplex_class.Solution.nodecnt;    %�ڵ�ĸ���
    result.itercount = Cplex_API(model.H,model.f,model.Aineq,model.bineq,model.Aeq,model.beq,model.lb,model.ub,model.ctype,GAP,TimeLimit,boolean_MILP);   %��������
    result.cons = size(cplex_class.Model.A,1);
    result.vars = size(cplex_class.Model.A,2);
    
end

if(strcmp(problem,'Relax'))    %�����������ɳڵ�����

    model.ctype(find(model.ctype == 'B')) = 'C';                        %�����������ĳ���������

    cplex_class = Cplex('Relax');
    cplex_class.Model.sense = 'minimize';        
    cplex_class.Model.Q = model.H;        
    cplex_class.Model.obj = model.f;
    cplex_class.Model.lb = model.lb;
    cplex_class.Model.ub = model.ub;
    cplex_class.Model.A = [model.Aineq;model.Aeq];
    cplex_class.Model.lhs = [-Inf .* ones(size(model.bineq,1),1);model.beq];
    cplex_class.Model.rhs = [model.bineq;model.beq];
    cplex_class.Model.ctype = model.ctype;
    
%     cplex_class.DisplayFunc = 'off';                        %off����ʾ������
    cplex_class.Param.timelimit.Cur = TimeLimit;
    cplex_class.Param.barrier.convergetol.Cur = 1e-12;      %Լ���������  
%     cplex_class.writeModel('2P.mps');     %�����ѧģ��
    
    cplex_class.solve();
    
    result.x = cplex_class.Solution.x;
    result.objval = cplex_class.Solution.objval;

    if(boolean_MILP == 1)    %1��ʾĿ�꺯�����Ի�
        result.objval = 0.5 * result.x' * model.orig_H * result.x + model.orig_f' * result.x;
    end
        
end

end
