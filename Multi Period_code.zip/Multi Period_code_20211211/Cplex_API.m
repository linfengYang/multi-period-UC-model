function iteration = Cplex_API(H,f,Aineq,bineq,Aeq,beq,lb,ub,ctype,GAP,TimeLimit,boolean_MILP)
    options = cplexoptimset;
    options.Display = 'off';
    options.mip.tolerances.mipgap = GAP;
    options.timelimit = TimeLimit;
    
    if(boolean_MILP == 1)  %1��ʾĿ�꺯�����Ի�
        [x,fval,exitflag,output] = cplexmilp(f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype,[],options);            
    else
        [x,fval,exitflag,output] = cplexmiqp(H,f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype,[],options);
    end

    iteration = output.iterations;
end
