function tao = v_tao( m,t,M,tao_location,var )
%����v��tao֮���ת��
    A = tao_location{m};
    lo = reshape(A(t + 1,t + 1 : m + M - 1),m + M - 1 - t,1);
    tao = lo(lo ~= 0);
    tao = tao + var * ones(size(tao,1),1);
end
