function tao = u_tao( m,t,M,tao_location,var )
%����u��tao֮���ת��
    A = tao_location{m};
    lo = reshape(A(m : t + 1,t + 1 : m + M - 1),(t + 2 - m) * (m + M - 1 - t),1);
    tao = lo(lo ~= 0);
    tao = tao + var * ones(size(tao,1),1);
end

