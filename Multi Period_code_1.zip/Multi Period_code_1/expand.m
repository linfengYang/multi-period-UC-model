%% ***************************************************************
%             ���ߣ���ʩ��
%             ԭ�����ڣ�2021��6��7��
%             �޸����ڣ�
%             ����˵������չUC��ģ��
%% ***************************************************************
function dataUC = expand(dataUC,times_T,times_Uit)
%expand ��չ��������
%   times_TΪ��չʱ�䣬24ʱ��εı�����1ָ24ʱ�Σ�2ָ24*2ʱ�Ρ���
%   times_UitΪ��չ���������1ָ��ǰ�����ļ��л��������һ��,��N*1��2ָN*2����

if(times_T > 1)         %��չʱ���
    
    dataUC.PD = repmat(dataUC.PD,times_T,1);
    dataUC.spin = repmat(dataUC.spin,times_T,1);
    dataUC.T = dataUC.T * times_T;
    
end

if(times_T < 1)         %��Сʱ���
    
    dataUC.T = dataUC.T * times_T;
    dataUC.PD = dataUC.PD(1 : dataUC.T,1);
    dataUC.spin = dataUC.spin(1 : dataUC.T,1);
    
end

if(times_Uit > 1)       %��չ����
    
    dataUC.PD = dataUC.PD * times_Uit;
    dataUC.spin = dataUC.spin * times_Uit;
    dataUC.N = dataUC.N * times_Uit;
    
    dataUC.alpha = reshape(repmat(dataUC.alpha,1,times_Uit)',dataUC.N,1);
    dataUC.beta = reshape(repmat(dataUC.beta,1,times_Uit)',dataUC.N,1);
    dataUC.gamma = reshape(repmat(dataUC.gamma,1,times_Uit)',dataUC.N,1);
    
    dataUC.p_low = reshape(repmat(dataUC.p_low,1,times_Uit)',dataUC.N,1);
    dataUC.p_up = reshape(repmat(dataUC.p_up,1,times_Uit)',dataUC.N,1);    
    dataUC.p_rampdown = reshape(repmat(dataUC.p_rampdown,1,times_Uit)',dataUC.N,1);
    dataUC.p_rampup = reshape(repmat(dataUC.p_rampup,1,times_Uit)',dataUC.N,1);
    dataUC.p_startup = reshape(repmat(dataUC.p_startup,1,times_Uit)',dataUC.N,1);
    dataUC.p_shutdown = reshape(repmat(dataUC.p_shutdown,1,times_Uit)',dataUC.N,1);

    dataUC.time_min_on = reshape(repmat(dataUC.time_min_on,1,times_Uit)',dataUC.N,1);
    dataUC.time_min_off = reshape(repmat(dataUC.time_min_off,1,times_Uit)',dataUC.N,1);
    dataUC.Cold_cost = reshape(repmat(dataUC.Cold_cost,1,times_Uit)',dataUC.N,1);
    dataUC.Hot_cost = reshape(repmat(dataUC.Hot_cost,1,times_Uit)',dataUC.N,1);  
    dataUC.Cold_hour = reshape(repmat(dataUC.Cold_hour,1,times_Uit)',dataUC.N,1);
    
    dataUC.time_on_off_ini = reshape(repmat(dataUC.time_on_off_ini,1,times_Uit)',dataUC.N,1);    
    dataUC.p_initial = reshape(repmat(dataUC.p_initial,1,times_Uit)',dataUC.N,1);
    dataUC.u0 = reshape(repmat(dataUC.u0,1,times_Uit)',dataUC.N,1);

end

end

