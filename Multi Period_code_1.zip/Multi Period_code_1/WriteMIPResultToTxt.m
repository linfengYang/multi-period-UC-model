%% ***************************************************************
%             ���ߣ���ʩ��
%             ԭ�����ڣ�2021��6��7��
%             �޸����ڣ�
%             ����˵������MIP������д���ı���
%% ***************************************************************
function WriteMIPResultToTxt(fid,index,model,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs,DC_flow)
%WRITERESULTTOTXT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if(DC_flow == 1)       %����ֱ������
    if(index == 1 )
        fprintf(fid,'Unit_Number\t Objval\t Status\t Runime\t MipGap\t nodes\t iterations\t cuts\t cons\t vars\t nonzs\t pre_cons\t pre_vars\t pre_nonzs\t Bus\r\n');
        fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',model.N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs,model.NodeNum);
    else
        fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',model.N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs,model.NodeNum);
    end
else                  %������ֱ������
    if(index == 1 )
        fprintf(fid,'Unit_Number\t Objval\t Status\t Runime\t MipGap\t nodes\t iterations\t cuts\t cons\t vars\t nonzs\t pre_cons\t pre_vars\t pre_nonzs\r\n');
        fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',model.N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs);
    else
        fprintf(fid,'%d\t %f\t %s\t %f\t %f\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\r\n',model.N,objval,status,runtime,mipgap,nodecount,itercount,cuts,cons,vars,nonzs,pre_cons,pre_vars,pre_nonzs);
    end
end

end
